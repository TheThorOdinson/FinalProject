import pygame
import math
import random


def game():
    pygame.init()

    clock = pygame.time.Clock()
    FPS = 60

    SCREEN_WIDTH = 1500
    SCREEN_HEIGHT = 600

    time_score = 0
    enemy_score = 0

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Endless Scroll")

    moon = pygame.image.load("moon.png")
    bg = pygame.image.load("bg.png").convert()
    bg_width = bg.get_width()

    moon_rect = moon.get_rect()
    moon_rect.topleft = (bg_width - moon_rect.width - 100, 50)
    player_idle = pygame.image.load("player_idle.png")
    player_blasting = pygame.image.load("player_blasting.png")
    player_jump = pygame.image.load("player_jump.png")
    player_crouch = pygame.image.load("player_crouch.png")
    bricks = pygame.image.load("bricks.png")
    ball_image = pygame.image.load("blasterball.png")

    player_width = 50
    player_height = 100
    original_player_height = player_height
    original_player_y = SCREEN_HEIGHT - original_player_height

    player_rect = pygame.Rect(SCREEN_WIDTH // 2 - player_width // 2, original_player_y, player_width, player_height)

    jump_sound = pygame.mixer.Sound("jump.wav")
    game_over_sound = pygame.mixer.Sound("game_over.wav")
    explosion_sound = pygame.mixer.Sound("explosion.wav")
    run_sound = pygame.mixer.Sound("run.wav")
    slide_sound = pygame.mixer.Sound("slide.wav")
    ding_sound = pygame.mixer.Sound("ding.wav")

    scroll = 0
    tiles = math.ceil(SCREEN_WIDTH / bg_width) + 1

    is_jumping = False
    jump_count = 10

    is_crouching = False

    brick_width = 64
    brick_height = 64
    brick_speed = 3
    bricks_list = []

    player_run_frames = [
        pygame.image.load("pixilart-frames/player_run_frame1.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame2.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame3.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame4.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame5.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame6.png").convert_alpha(),
        pygame.image.load("pixilart-frames/player_run_frame7.png").convert_alpha(),
    ]
    player_run2_frames = [
        pygame.image.load("pixilart-frames2/player_run2_frame1.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame2.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame3.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame4.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame5.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame6.png").convert_alpha(),
        pygame.image.load("pixilart-frames2/player_run2_frame7.png").convert_alpha(),
    ]

    enemy_frames = [
        pygame.image.load("pixilart-frames3/enemy_frame1.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame2.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame3.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame4.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame5.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame6.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame7.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame8.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame9.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame10.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame11.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame12.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame13.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame14.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame15.png").convert_alpha(),
        pygame.image.load("pixilart-frames3/enemy_frame16.png").convert_alpha(),
    ]

    ball_frames = [
        pygame.image.load("pixilart-frames4/blaster_hit1.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit2.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit3.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit4.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit5.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit6.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit7.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit8.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit9.png").convert_alpha(),
        pygame.image.load("pixilart-frames4/blaster_hit10.png").convert_alpha(),
    ]

    enemy_width = 64
    enemy_height = 64
    enemy_speed = 3
    enemies_list = []

    ball_list = []
    ball_height = 64
    ball_width = 64
    ball_speed = 15

    current_run_frame = 0
    animation_timer = 0
    animation_speed = 3

    def create_brick(x, y):
        brick = pygame.Rect(x, y, brick_width, brick_height)
        bricks_list.append(brick)

    for i in range(0, SCREEN_WIDTH + brick_width * 2, brick_width):
        create_brick(i, SCREEN_HEIGHT - brick_height)

    run = True
    end = False
    while run:
        clock.tick(FPS)

        time_score += 1

        for i in range(0, tiles):
            screen.blit(bg, (i * bg_width + scroll + 1, 0))

        screen.blit(moon, moon_rect.topleft)

        player_rect.x -= 3

        keys = pygame.key.get_pressed()

        if not is_crouching:
            if keys[pygame.K_a] and player_rect.left > 0:
                player_rect.x -= 8
            if keys[pygame.K_d] and player_rect.right < SCREEN_WIDTH:
                player_rect.x += 8
        elif is_crouching:
            if keys[pygame.K_a] and player_rect.left > 0:
                player_rect.x -= 4
            if keys[pygame.K_d] and player_rect.right < SCREEN_WIDTH:
                player_rect.x += 4

        if not is_jumping:
            if keys[pygame.K_w]:
                is_jumping = True
                jump_sound.play()
        else:
            if jump_count >= -10:
                neg = 1
                if jump_count < 0:
                    neg = -1
                player_rect.y -= (jump_count ** 2) * 0.5 * neg
                jump_count -= 1
            else:
                is_jumping = False
                jump_count = 10
                player_rect.y -= 5

        if keys[pygame.K_s]:
            if not is_crouching:
                is_crouching = True
                player_rect.y += original_player_height // 2
                player_rect.height //= 2
                if keys[pygame.K_a] or keys[pygame.K_d]:
                    slide_sound.play()
        elif is_crouching:
            is_crouching = False
            player_rect.y = original_player_y
            player_rect.height *= 2

        if not is_crouching:
            if is_jumping:
                player_model = player_jump
            elif keys[pygame.K_SPACE]:
                player_model = player_blasting
            elif keys[pygame.K_a] and keys[pygame.K_d]:
                player_model = player_idle
            elif keys[pygame.K_d]:
                player_model = player_run_frames[current_run_frame]
                animation_timer += 1
                if animation_timer >= animation_speed:
                    current_run_frame = (current_run_frame + 1) % len(player_run_frames)
                    animation_timer = 0
                    if current_run_frame == 1 or current_run_frame == 5:
                        run_sound.play()
            elif keys[pygame.K_a]:
                player_model = player_run2_frames[current_run_frame]
                animation_timer += 1
                if animation_timer >= animation_speed:
                    current_run_frame = (current_run_frame + 1) % len(player_run_frames)
                    animation_timer = 0
                    if current_run_frame == 1 or current_run_frame == 5:
                        run_sound.play()
            else:
                player_model = player_idle
        else:
            player_model = player_crouch

        for brick in bricks_list:
            brick.x -= brick_speed
            screen.blit(bricks, brick.topleft)

            if player_rect.colliderect(brick):
                player_rect.y = brick.y - player_rect.height
                is_jumping = False
                jump_count = 10

        if bricks_list and bricks_list[0].x < -brick_width:
            bricks_list.pop(0)
        if not bricks_list or bricks_list[-1].x < SCREEN_WIDTH:
            create_brick(SCREEN_WIDTH + brick_width, SCREEN_HEIGHT - brick_height)

        screen.blit(player_model, player_rect.topleft)

        if player_rect.right < 0 or end:
            end = True
            enemies_list = []

        time_score_font = pygame.font.Font("Source_Code_Pro/static/SourceCodePro-Regular.ttf", 36)
        time_score_text = time_score_font.render(f"Time Score: {time_score}", True, (255, 255, 255))
        screen.blit(time_score_text, (10, 10))

        enemy_score_font = pygame.font.Font("Source_Code_Pro/static/SourceCodePro-Regular.ttf", 36)
        enemy_score_text = enemy_score_font.render(f"Enemy Score: {enemy_score}", True, (255, 255, 255))
        screen.blit(enemy_score_text, (10, 50))

        if enemy_score > 0 and enemy_score % 100 == 0:
            ding_sound.play()

        scroll -= 2

        if abs(scroll) > bg_width:
            scroll = 0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        for enemy in enemies_list:
            if player_rect.colliderect(enemy.rect):
                end = True
                ball_list = []

        create_enemy(enemies_list, SCREEN_WIDTH, enemy_frames, enemy_width, enemy_height, enemy_speed)
        enemies_list = handle_enemies(enemies_list, player_rect, screen)

        pygame.display.update()

        create_ball(ball_list, player_rect, ball_width, ball_height, ball_speed, keys[pygame.K_SPACE], ball_image)

        ball_list = update_balls(ball_list, SCREEN_WIDTH)

        for ball in ball_list:
            for enemy in enemies_list:
                if ball.rect.colliderect(enemy.rect) and ball.rect.right > enemy.rect.right:
                    screen.blit(ball_frames[ball.current_frame], ball.rect.topleft)
                    ball.animation_timer += 1
                    ball.speed = 0
                    enemy.speed = 0

                    if ball.animation_timer >= 1:
                        ball.current_frame = (ball.current_frame + 1) % len(ball_frames)
                        ball.animation_timer = 0

                        if ball.current_frame == 1:
                            explosion_sound.play()

                    if ball.current_frame == len(ball_frames) - 1:
                        ball_list.remove(ball)
                        enemies_list.remove(enemy)
                        enemy_score += 1

            screen.blit(ball_frames[ball.current_frame], ball.rect.topleft)

            pygame.display.update()

        if end:
            time_score = 0
            enemy_score = 0
            enemies_list = []
            game_over_sound.play()
            game_over_font = pygame.font.Font(None, 74)
            game_over_text = game_over_font.render("Game Over", True, (255, 0, 0))

            restart_font = pygame.font.Font(None, 36)
            restart_text = restart_font.render("Do you want to play again? Y/N", True, "White")
            restart_rect = restart_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50))

            game_over_rect = game_over_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
            screen.blit(game_over_text, game_over_rect.topleft)

            is_jumping = False
            jump_count = 10
            is_crouching = False
            bricks_list = []
            scroll = 0

            pygame.display.update()

            game_over_rect = game_over_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
            screen.blit(game_over_text, game_over_rect.topleft)

            screen.blit(restart_text, restart_rect.topleft)

            pygame.display.update()

            waiting_for_input = True
            while waiting_for_input:
                for event in pygame.event.get():
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_y:
                            player_rect.x = SCREEN_WIDTH // 2 - player_width // 2
                            player_rect.y = original_player_y
                            is_jumping = False
                            jump_count = 10
                            is_crouching = False
                            bricks_list = []
                            scroll = 0
                            end = False
                            waiting_for_input = False

                        elif event.key == pygame.K_n:
                            run = False
                            waiting_for_input = False

                    if event.type == pygame.QUIT:
                        run = False
                        waiting_for_input = False

            for i in range(0, SCREEN_WIDTH + brick_width * 2, brick_width):
                create_brick(i, SCREEN_HEIGHT - brick_height)

            pygame.display.update()
            clock.tick(FPS)

    pygame.quit()


class Enemy:
    def __init__(self, x, y, frames, width, height, speed, animation_speed):
        self.frames = frames
        self.current_frame = 0
        self.animation_timer = 0
        self.animation_speed = animation_speed
        self.rect = pygame.Rect(x, y, width, height)
        self.speed = speed

    def update(self):
        self.rect.x -= self.speed

        self.animation_timer += 1
        if self.animation_timer >= self.animation_speed:
            self.current_frame = (self.current_frame + 1) % len(self.frames)
            self.animation_timer = 0

    def draw(self, screen):
        screen.blit(self.frames[self.current_frame], self.rect.topleft)


def create_enemy(enemies_list, SCREEN_WIDTH, enemy_frames, enemy_width, enemy_height, enemy_speed):
    if random.random() < 0.01:
        spawn_y = 472
        enemy = Enemy(SCREEN_WIDTH, spawn_y, enemy_frames, enemy_width, enemy_height, enemy_speed, 3)
        enemies_list.append(enemy)


def handle_enemies(enemies_list, player_rect, screen):
    global end
    for enemy in enemies_list:
        enemy.update()
        enemy.draw(screen)

        if enemy.rect.colliderect(player_rect):
            end = True
            enemies_list = []

    enemies_list = [enemy for enemy in enemies_list if enemy.rect.right > 0]

    return enemies_list


class Ball:
    def __init__(self, x, y, width, height, speed, frames):
        self.rect = pygame.Rect(x, y, width, height)
        self.speed = speed
        self.frames = frames
        self.animation_timer = 0
        self.current_frame = 0

    def update(self):
        self.rect.x += self.speed


def create_ball(ball_list, player_rect, ball_width, ball_height, ball_speed, player_blasting, ball_frames):
    blast_sound = pygame.mixer.Sound("blast.wav")
    if player_blasting and not ball_list:
        spawn_x = player_rect.right
        spawn_y = player_rect.centery - 20
        ball = Ball(spawn_x, spawn_y, ball_width, ball_height, ball_speed, ball_frames.copy())
        ball_list.append(ball)
        blast_sound.play()


def update_balls(ball_list, SCREEN_WIDTH):
    for ball in ball_list:
        ball.update()

    ball_list = [ball for ball in ball_list if ball.rect.left < SCREEN_WIDTH]

    return ball_list
