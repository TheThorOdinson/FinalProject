Just run main and it should work. :) \
If it doesn't, email me at EstabrooksCD@hendrix.edu and I'll try to get back to you ASAP.