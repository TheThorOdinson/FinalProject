import game

game.game()