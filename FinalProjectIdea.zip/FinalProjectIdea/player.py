import pygame

class Player:
    def __init__(self, screen_width, screen_height):
        self.width = 50
        self.height = 100
        self.original_height = self.height
        self.original_y = screen_height - self.original_height
        self.rect = pygame.Rect(screen_width // 2 - self.width // 2, self.original_y, self.width, self.height)
        self.is_jumping = False
        self.jump_count = 10
        self.is_crouching = False



    def update(self, keys):
        if not self.is_crouching:
            if keys[pygame.K_a] and self.rect.left > 0:
                self.rect.x -= 8
            if keys[pygame.K_d] and self.rect.right < 1500:
                self.rect.x += 8
        elif self.is_crouching:
            if keys[pygame.K_a] and self.rect.left > 0:
                self.rect.x -= 4
            if keys[pygame.K_d] and self.rect.right < 1500:
                self.rect.x += 4

        if not self.is_jumping:
            if keys[pygame.K_w]:
                self.is_jumping = True
        else:
            if self.jump_count >= -10:
                neg = 1
                if self.jump_count < 0:
                    neg = -1
                self.rect.y -= (self.jump_count ** 2) * 0.5 * neg
                self.jump_count -= 1
            else:
                self.is_jumping = False
                self.jump_count = 10
                self.rect.y -= 5

    def crouch_toggle(self):
        if self.is_crouching:
            self.is_crouching = False
            self.rect.y = self.original_y
            self.rect.height *= 2
        else:
            self.is_crouching = True
            self.rect.y += self.original_height // 2
            self.rect.height //= 2

    def get_model(self):
        keys = pygame.key.get_pressed()
        self.idle = pygame.image.load("/Users/connorestabrooks/Desktop/player_idle.png")
        self.run_frames = [
            pygame.image.load("/Users/connorestabrooks/Desktop/pixilart-frames/player_run_frame1.png").convert_alpha(),
            pygame.image.load("/Users/connorestabrooks/Desktop/pixilart-frames/player_run_frame2.png").convert_alpha(),
            pygame.image.load("/Users/connorestabrooks/Desktop/pixilart-frames/player_run_frame3.png").convert_alpha(),
            pygame.image.load("/Users/connorestabrooks/Desktop/pixilart-frames/player_run_frame4.png").convert_alpha(),
            pygame.image.load("/Users/connorestabrooks/Desktop/pixilart-frames/player_run_frame5.png").convert_alpha(),
            pygame.image.load("/Users/connorestabrooks/Desktop/pixilart-frames/player_run_frame6.png").convert_alpha(),
            pygame.image.load("/Users/connorestabrooks/Desktop/pixilart-frames/player_run_frame7.png").convert_alpha(),
        ]
        self.run2_frames = [
            pygame.image.load(
                "/Users/connorestabrooks/Desktop/pixilart-frames2/player_run2_frame1.png").convert_alpha(),
            pygame.image.load(
                "/Users/connorestabrooks/Desktop/pixilart-frames2/player_run2_frame2.png").convert_alpha(),
            pygame.image.load(
                "/Users/connorestabrooks/Desktop/pixilart-frames2/player_run2_frame3.png").convert_alpha(),
            pygame.image.load(
                "/Users/connorestabrooks/Desktop/pixilart-frames2/player_run2_frame4.png").convert_alpha(),
            pygame.image.load(
                "/Users/connorestabrooks/Desktop/pixilart-frames2/player_run2_frame5.png").convert_alpha(),
            pygame.image.load(
                "/Users/connorestabrooks/Desktop/pixilart-frames2/player_run2_frame6.png").convert_alpha(),
            pygame.image.load(
                "/Users/connorestabrooks/Desktop/pixilart-frames2/player_run2_frame7.png").convert_alpha(),
        ]
        self.jump = pygame.image.load("/Users/connorestabrooks/Desktop/player_jump.png")
        self.crouch = pygame.image.load("/Users/connorestabrooks/Desktop/player_crouch.png")


        current_run_frame = 0
        animation_timer = 0
        animation_speed = 3
        if not self.is_crouching:
            if self.is_jumping:
                return self.jump
            elif keys[pygame.K_a] and keys[pygame.K_d]:
                return self.idle
            elif keys[pygame.K_d]:
                return self.run_frames[current_run_frame]
            elif keys[pygame.K_a]:
                return self.run2_frames[current_run_frame]
            else:
                return self.idle
        else:
            return self.crouch
